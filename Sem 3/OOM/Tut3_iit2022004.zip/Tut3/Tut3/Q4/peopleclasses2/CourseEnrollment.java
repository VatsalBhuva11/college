
package peopleclasses2;

public class CourseEnrollment {
    //cant do as java doestn support multiple inheritance, we can use interfaces but that hasnt been covered yet
}
