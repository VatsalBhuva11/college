
package peopleclasses2;


public class Student extends Person {
    int studentID;
    int batch;
    public void displayStudInfo(){
        System.out.println("NAME: "+this.name+", AGE: "+this.age+", ID: "+this.studentID+", Batch: "+this.batch);
    }
    public int getAge(){
        return this.age;
    }
}
