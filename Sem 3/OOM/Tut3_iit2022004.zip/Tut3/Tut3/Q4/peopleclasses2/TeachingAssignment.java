
package peopleclasses2;

public class TeachingAssignment {
    //cant do as java doesnt support multiple inheritance, we can use interfaces and abstract classes but that hasnt been covered yet
}
