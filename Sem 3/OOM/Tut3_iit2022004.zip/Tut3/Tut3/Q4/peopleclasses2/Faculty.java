
package peopleclasses2;

public class Faculty extends Person {
    int employeeID;
    String department;
    public void displayInfo(){
        System.out.println("NAME: "+this.name+", AGE: "+this.age+", ID: "+this.employeeID+", Department: "+this.department);
    }
    public int getAge(){
        return this.age;
    }
}
