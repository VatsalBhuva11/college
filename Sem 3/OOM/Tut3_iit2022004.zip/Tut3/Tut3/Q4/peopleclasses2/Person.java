
package peopleclasses2;

public class Person {
    String name;
    int age;
    
}
