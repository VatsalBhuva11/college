
package peopleclasses2;

public class Course {
    int courseCode;
    String courseName;
}

