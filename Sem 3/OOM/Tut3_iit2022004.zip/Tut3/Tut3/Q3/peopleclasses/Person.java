
package peopleclasses;

public class Person {
    
}
