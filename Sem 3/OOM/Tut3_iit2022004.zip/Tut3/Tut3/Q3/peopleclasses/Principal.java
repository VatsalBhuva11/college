
package peopleclasses;

public class Principal extends Person{
    int principalID;
    int yearsOfExperience;
    public void displayInfo(){
        System.out.println("NAME: "+this.name+", AGE: "+this.age+", GENDER: "+this.gender+", ID: "+this.principalID+", EXPERIENCE: "+this.yearsOfExperience);
    }
    public void displayExperience(){
        System.out.println("Experience IS "+this.yearsOfExperience+" years");
    }
}
