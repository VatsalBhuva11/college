
package peopleclasses;

public class Teacher {
    
}
