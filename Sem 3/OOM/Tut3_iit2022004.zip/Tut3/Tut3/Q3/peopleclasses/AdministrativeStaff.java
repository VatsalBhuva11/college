
package peopleclasses;

public class AdministrativeStaff {
    
}
