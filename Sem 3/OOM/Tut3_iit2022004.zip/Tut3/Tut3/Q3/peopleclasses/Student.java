
package peopleclasses;

public class Student {
    
}
